package tarea1.electrodomestico;

public class Television extends Electrodomestico {

}
